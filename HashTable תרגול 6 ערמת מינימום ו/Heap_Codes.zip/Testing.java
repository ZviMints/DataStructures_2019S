package S6.Heap;

import java.util.Arrays;

public class Testing {

	public static void main(String[] args) {
		MaxHeap heap = new MaxHeap(new int[]{1,2,3,4,5,6,7,8});
//		heap.print();
//		System.out.println(heap.GetMax());
		
		int[] ArrayToSorted = {9,8,7,6,5,4,3,2,1,0,-1,-2,-3,-4};
		heapSort(ArrayToSorted);
		System.out.println(Arrays.toString(ArrayToSorted));
	}

	private static void heapSort(int[] arr) {
		MaxHeap heap = new MaxHeap(arr); // O(n)
		for(int i=0; i<arr.length; i++) {
			int max = heap.remove_max();
			arr[arr.length - i - 1] = max;
		}
	}

}
